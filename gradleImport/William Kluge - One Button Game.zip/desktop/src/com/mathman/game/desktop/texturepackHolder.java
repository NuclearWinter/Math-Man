package com.mathman.game.desktop;
import com.badlogic.gdx.tools.texturepacker.TexturePacker;

public class texturepackHolder {
    public static void main (String[] args) throws Exception {
        TexturePacker.process("/Users/wkluge17/Desktop/mathman", "/Users/wkluge17/Desktop", "spritesheets");
    }
}