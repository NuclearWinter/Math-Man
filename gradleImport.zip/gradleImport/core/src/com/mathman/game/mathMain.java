package com.mathman.game;

import java.util.Calendar;

import com.badlogic.gdx.ApplicationListener;
import com.badlogic.gdx.Gdx;
import com.badlogic.gdx.InputProcessor;
import com.badlogic.gdx.graphics.GL20;
import com.badlogic.gdx.graphics.Texture;
import com.badlogic.gdx.graphics.g2d.BitmapFont;
import com.badlogic.gdx.graphics.g2d.GlyphLayout;
import com.badlogic.gdx.graphics.g2d.Sprite;
import com.badlogic.gdx.graphics.g2d.SpriteBatch;
import com.badlogic.gdx.graphics.g2d.TextureAtlas;
import com.badlogic.gdx.graphics.g2d.TextureAtlas.AtlasRegion;
import com.badlogic.gdx.utils.Timer;
import com.badlogic.gdx.utils.Timer.Task;

public class mathMain implements ApplicationListener, InputProcessor {
	public static final String TAG = "MathMan";
    private SpriteBatch batch;
    private TextureAtlas textureAtlas;
    private Sprite mathMan;
    private int currentFrame = 1;
    private String currentAtlasKey = new String("0001");
    
    private Texture background;
    
    private float playerX = 120;
    private float playerY = 100;
    
    private long deltaCheck = System.currentTimeMillis();
    

    private int correctText;
    BitmapFont correctBitmap;
    
    private int streakText;
    BitmapFont streakBitmap;
    
    private String answerTopText;
    BitmapFont answerTopBitmap;
    
    private String answerMidText;
    BitmapFont answerMidBitmap;
    
    private String answerBotText;
    BitmapFont answerBotBitmap;
    
    private String questionText;
    BitmapFont questionBitmap;
    
    private int touchX = 8000;
    private int touchY = 8000;
    
    private Calendar cal = Calendar.getInstance();
    private java.util.Random generator;
    
    private int firstNumber;
    private int secondNumber;
    private int answer;
    private int fakeAnswerOne;
    private int fakeAnswerTwo;
    
    private String correctSector = "";
    
    
    @Override
    public void create() {   
    	Gdx.input.setInputProcessor(this); //InputProcessor
        batch = new SpriteBatch();
        textureAtlas = new TextureAtlas(Gdx.files.internal("data/spritesheets.atlas"));
        AtlasRegion region = textureAtlas.findRegion("0001");
        mathMan = new Sprite(region);
        mathMan.setPosition(120, (Gdx.graphics.getHeight()/2));
        mathMan.scale(3f);
        
        background = new Texture(Gdx.files.internal("data/background.png"));
        
        Timer.schedule(new Task(){
                @Override
                public void run() {
                    currentFrame++;
                    if(currentFrame > 4)
                        currentFrame = 1;
                    
                    currentAtlasKey = String.format("%04d", currentFrame);
                    mathMan.setRegion(textureAtlas.findRegion(currentAtlasKey));
                }
            }
            ,0,1/30.0f);

        correctText = 0;
        correctBitmap = new BitmapFont();
        
        streakText = 0;
        streakBitmap = new BitmapFont();
        
        answerTopText ="";
        answerTopBitmap = new BitmapFont();
        
        answerMidText ="";
        answerMidBitmap = new BitmapFont();
        
        answerBotText ="";
        answerBotBitmap = new BitmapFont();
        
        questionText ="0";
        questionBitmap = new BitmapFont();
        
        generator = new java.util.Random();
        
       makeQuestion();
    }

    @Override
    public void dispose() {
        batch.dispose();
        textureAtlas.dispose();
    }

    @Override
    public void render() {     
    		Gdx.gl.glClearColor(1, 1, 1, 1);
    		Gdx.gl.glClear(GL20.GL_COLOR_BUFFER_BIT);
        
    		loopDraw();
    		
    		/*answerBotBitmap.setColor(1.0f, 1.0f, 1.0f, 1.0f);
    		answerMidBitmap.setColor(1.0f, 1.0f, 1.0f, 1.0f);
    		answerTopBitmap.setColor(1.0f, 1.0f, 1.0f, 1.0f);
    		questionBitmap.setColor(1.0f, 1.0f, 1.0f, 1.0f);
    		correctBitmap.setColor(1.0f, 1.0f, 1.0f, 1.0f);
    		streakBitmap.setColor(1.0f, 1.0f, 1.0f, 1.0f);*/
    		
    		batch.begin();
    		batch.draw(background, 0, 0);
    		mathMan.draw(batch);
    		
    		answerBotBitmap.draw(batch, answerBotText+"", 1600, 180); //Bot answer
    		
    		answerMidBitmap.draw(batch, answerMidText+"", 1600, 540); //Mid answer
    		
    		answerTopBitmap.draw(batch, answerTopText+"", 1600, 900); //Top answer
    		
    		questionBitmap.draw(batch, questionText+"", 910, 540); //Question
    		
    		//correctBitmap.draw(batch, correctText+"", 910, 1060); //Top counter
    		
    		//streakBitmap.draw(batch, streakText+"", 910, 1030); //Bot counter
    		
    		batch.end();
    } //End render
    
    private void loopDraw() {
    	Gdx.input.setInputProcessor(this); //InputProcessor
    	if (System.currentTimeMillis() - deltaCheck > .016666667) { //This is so that it displays at 60fps
    		if (mathMan.getY() > Gdx.graphics.getHeight() || mathMan.getY() <= 0) { //If it is past either side of the Y axis
	    		playerY = mathMan.getOriginY(); //Change player Y to equal half of the height
	    		mathMan.setY(playerY); //Move the player here
	    	}
	    	
	    	if ((touchY > 1007) && (touchX < 73)) {
	    		playerY += 6;
	    	}
    		
	    	if (playerX >= Gdx.graphics.getWidth()) { //If it is past the end of the x-axis
	    		mathMan.setX(mathMan.getOriginX()); //Set its X to the starting point
	    		mathMan.setY(mathMan.getOriginY()); //And its Y to the starting point
	    		playerX = mathMan.getOriginX();  //Set player X to its new cordinates
	    		playerY = mathMan.getOriginY(); //Set player Y to its new cordinates
	    		
	    		checkAnswer(playerY);
	    		makeQuestion();
	    		//TODO make delay so next question is generated before continuing
	    		}
	    	else { //If it is not past the x-axis
	    		playerX += 3; //Add three to the player's position
	    		mathMan.setX(playerX); //Move the player to that position
	    		mathMan.setY(playerY);
	    	}
    		
	    	
    	} //End Time check
    		deltaCheck = System.currentTimeMillis(); //Set the deltaCheck variable to be the last time this was run
    } //End loopDraw()
    
    
    private void makeQuestion() {
    	refreshGenerator(System.currentTimeMillis() * 316);
    	firstNumber = generator.nextInt(11); //numbers 0-10
    	
    	refreshGenerator(System.currentTimeMillis() * 69);
    	secondNumber = generator.nextInt(11); //numbers 0-10
    	
    	refreshGenerator(System.currentTimeMillis() * -20);
    	int setFunction = generator.nextInt(1);
    	
    	refreshGenerator(System.currentTimeMillis() * 893);
    	int fakeNumberOne = generator.nextInt(11); //numbers 0-10
    	
    	refreshGenerator(System.currentTimeMillis() * 137);
    	int fakeNumberTwo = generator.nextInt(11); //numbers 0-10
    	
    	if (firstNumber < secondNumber && setFunction == 0) { // first + second
    		questionText = firstNumber + "+" + secondNumber;
    		answer = firstNumber+secondNumber;
    		fakeAnswerOne = firstNumber + fakeNumberOne;
    		fakeAnswerTwo = fakeNumberTwo + firstNumber;
    		orderAnswers();
    	} //End If
    	
    	else if (firstNumber < secondNumber && setFunction == 1) { //second - first
    		questionText = secondNumber + "-" + firstNumber;
    		answer = secondNumber-firstNumber;
    		fakeAnswerOne = (fakeNumberOne-fakeNumberTwo)*(fakeNumberOne-fakeNumberTwo);
    		fakeAnswerTwo = fakeNumberTwo + firstNumber;
    		orderAnswers();
    	} //End If
    	
    	else if (firstNumber > secondNumber && setFunction == 0) { // first + second
    		questionText = firstNumber + "+" + secondNumber;
    		answer = firstNumber+secondNumber;
    		fakeAnswerOne = fakeNumberTwo + secondNumber;
    		fakeAnswerTwo = fakeNumberOne + firstNumber;
    		orderAnswers();
    	} //End If
    	
    	else if (firstNumber > secondNumber && setFunction == 1) { // first - second
    		questionText = firstNumber + "-" + secondNumber;
    		answer = firstNumber-secondNumber;
    		fakeAnswerOne = fakeNumberOne + secondNumber;
    		fakeAnswerTwo = fakeNumberOne + fakeNumberTwo;
    		orderAnswers();
    	} //End If
    	
    	else if (firstNumber == secondNumber && setFunction == 0) { // first + second
    		questionText = firstNumber + "+" + secondNumber;
    		answer = firstNumber+secondNumber;
    		fakeAnswerOne = fakeNumberTwo + firstNumber;
    		fakeAnswerTwo = fakeNumberOne + secondNumber;
    		orderAnswers();
    	} //End If
    	
    	else if (firstNumber == secondNumber && setFunction == 1) { // first - second
    		questionText = firstNumber + "-" + secondNumber;
    		answer = firstNumber - secondNumber;
    		fakeAnswerOne = fakeNumberOne + fakeNumberTwo;
    		fakeAnswerTwo = secondNumber + fakeNumberOne;
    		orderAnswers();
    	} //End If
    	
    	
} //End makeQuestion
    
    private void refreshGenerator (long seed) {
    	generator.setSeed(seed);
    }
    
    private void orderAnswers() { //Assigns our values to the strings so that they can be printed on the screen
    	refreshGenerator(System.currentTimeMillis() * 70);
    	int order = generator.nextInt(3); //0-2
    	
    	if (order == 0) {
			answerTopText = answer + ""; //These + ""s convert our ints to Strings
			answerMidText = fakeAnswerOne + "";
			answerBotText = fakeAnswerTwo + "";
			correctSector = "Top";
		}
		else if (order == 1) {
			answerTopText = fakeAnswerTwo + "";
			answerMidText = answer + "";
			answerBotText = fakeAnswerOne + "";
			correctSector = "Mid";
		}
		else {
			answerTopText = fakeAnswerOne + "";
			answerMidText = fakeAnswerTwo + "";
			answerBotText = answer + "";
			correctSector = "Bot";
		}
    } //End orderAnswers
    
    private void checkAnswer(double playerYposition) {
    	if (playerYposition > 90 && playerYposition < 270) {
    		if (correctSector == "Bot")
    			handleAnswer(true);
    		else 
    			handleAnswer(false);
    	}
    	else if (playerYposition > 450 && playerYposition < 630) {
    		if (correctSector == "Mid")
    			handleAnswer(true);
    		else 
    			handleAnswer(false);
    	}
    	else if (playerYposition > 812 && playerYposition < 995) {
    		if (correctSector == "Top") 
    			handleAnswer(true);
    		else 
    			handleAnswer(false);
    	}
    } //End checkAnswer
    
    private void handleAnswer(boolean correct) {
    	if (correct) {
    		++correctText;
    		++streakText;
    	}
    	else 
    		streakText = 0;
    } //End handleAnswer

    @Override
    public void resize(int width, int height) {
    }

    @Override
    public void pause() {
    }

    @Override
    public void resume() {
    }

	@Override
	public boolean keyDown(int keycode) {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public boolean keyUp(int keycode) {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public boolean keyTyped(char character) {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public boolean touchDown(int screenX, int screenY, int pointer, int button) {
		touchX = Gdx.input.getX();
		touchY = Gdx.input.getY();
		return true;
	}

	@Override
	public boolean touchUp(int screenX, int screenY, int pointer, int button) {
		touchX = 8000;
		touchY = 8000;
		return false;
	}

	@Override
	public boolean touchDragged(int screenX, int screenY, int pointer) {
		return false;
	}

	@Override
	public boolean mouseMoved(int screenX, int screenY) {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public boolean scrolled(int amount) {
		// TODO Auto-generated method stub
		return false;
	}
}